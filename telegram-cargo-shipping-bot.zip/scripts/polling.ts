/*
  Long-polling runner for Telegram bot (no domain required).
  Run: npx tsx scripts/polling.ts
*/
import { handleUpdate, callTelegram } from "@/bot/handler";

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
if (!TOKEN) {
  // eslint-disable-next-line no-console
  console.error("TELEGRAM_BOT_TOKEN is not set");
  process.exit(1);
}

async function deleteWebhook() {
  await callTelegram("deleteWebhook", { drop_pending_updates: false });
}

async function getUpdates(offset?: number) {
  const url = `https://api.telegram.org/bot${TOKEN}/getUpdates`;
  const body: any = {
    timeout: 50,
    allowed_updates: ["message", "edited_message", "callback_query"],
  };
  if (offset !== undefined) body.offset = offset;

  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(`getUpdates failed: ${res.status} ${JSON.stringify(data)}`);
  return data.result as any[];
}

async function main() {
  // Ensure webhook is disabled for polling mode
  await deleteWebhook().catch((e) => console.error("deleteWebhook error", e));

  let offset: number | undefined = undefined;

  // eslint-disable-next-line no-constant-condition
  while (true) {
    try {
      const updates = await getUpdates(offset);
      for (const upd of updates) {
        try {
          await handleUpdate(upd);
        } catch (e) {
          console.error("handleUpdate error", e);
        }
        offset = Math.max(offset ?? 0, Number(upd.update_id) + 1);
      }
    } catch (e) {
      console.error("polling cycle error", e);
      await new Promise((r) => setTimeout(r, 2000));
    }
  }
}

main();
