import { pgTable, serial, text, integer, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";

// Pricing settings configured by the bot owner (single-row table is fine)
export const pricingSettings = pgTable("pricing_settings", {
  id: serial("id").primaryKey(),
  currency: text("currency").notNull().default("RUB"),
  baseCityPrice: integer("base_city_price").notNull().default(1500), // ₽
  cityKmIncluded: integer("city_km_included").notNull().default(20), // km included in base
  cityPerKm: integer("city_per_km").notNull().default(30), // ₽ per km inside city over included
  mkadExitFee: integer("mkad_exit_fee").notNull().default(500), // ₽ leaving MKAD
  moPerKm: integer("mo_per_km").notNull().default(35), // ₽ per km outside MKAD
  minOrderPrice: integer("min_order_price").notNull().default(1500), // ₽ minimum order
  loaderHourRate: integer("loader_hour_rate").notNull().default(600), // ₽ per loader per hour
  loadingMinHours: integer("loading_min_hours").notNull().default(2), // minimal hours billed
  extraStopFee: integer("extra_stop_fee").notNull().default(300), // ₽ per extra stop
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: false }).notNull().defaultNow(),
});

// Telegram per-chat session state for the conversation flow
export const tgSessions = pgTable("tg_sessions", {
  chatId: text("chat_id").primaryKey(),
  state: jsonb("state"), // arbitrary JSON { step, data }
  updatedAt: timestamp("updated_at", { withTimezone: false }).notNull().defaultNow(),
});

// Saved quotations for audit/analytics
export const tgQuotes = pgTable("tg_quotes", {
  id: serial("id").primaryKey(),
  chatId: text("chat_id").notNull(),
  payload: jsonb("payload"), // { inputs, breakdown }
  total: integer("total").notNull(),
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
});

// Driver business card + vehicle characteristics (one profile per Telegram user)
export const tgDrivers = pgTable("tg_drivers", {
  userId: text("user_id").primaryKey(),
  chatId: text("chat_id").notNull(),
  fullName: text("full_name").notNull().default(""),
  phone: text("phone").notNull().default(""),
  carModel: text("car_model").notNull().default(""),
  carType: text("car_type").notNull().default(""),
  maxPayloadKg: integer("max_payload_kg").notNull().default(1000),
  lengthCm: integer("length_cm").notNull().default(0),
  widthCm: integer("width_cm").notNull().default(0),
  heightCm: integer("height_cm").notNull().default(0),
  volumeM3: text("volume_m3").notNull().default(""),
  serviceArea: text("service_area").notNull().default("Москва и МО"),
  notes: text("notes").notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: false }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: false }).notNull().defaultNow(),
});
