import { db } from "@/db";
import { pricingSettings, tgDrivers, tgQuotes, tgSessions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type PricingRow = Awaited<ReturnType<typeof getSettings>>;
type DriverRow = Awaited<ReturnType<typeof getDriverProfile>>;

type AdminField =
  | "currency"
  | "baseCityPrice"
  | "cityKmIncluded"
  | "cityPerKm"
  | "mkadExitFee"
  | "moPerKm"
  | "minOrderPrice"
  | "loaderHourRate"
  | "loadingMinHours"
  | "extraStopFee";

type DriverField =
  | "fullName"
  | "phone"
  | "carModel"
  | "carType"
  | "maxPayloadKg"
  | "lengthCm"
  | "widthCm"
  | "heightCm"
  | "volumeM3"
  | "serviceArea"
  | "notes";

type SessionState = {
  step:
    | "idle"
    | "quote_trip_type"
    | "quote_city_km"
    | "quote_mo_outside_km"
    | "quote_extra_stops"
    | "quote_loaders_count"
    | "quote_loading_hours"
    | "admin_wait_value"
    | "driver_wait_value";
  data: {
    tripType?: "city" | "mo";
    cityKm?: number;
    moOutsideKm?: number;
    extraStops?: number;
    loadersCount?: number;
    loadingHours?: number;
  };
  adminField?: AdminField;
  driverField?: DriverField;
};

const ADMIN_FIELDS: { key: AdminField; label: string; numeric: boolean }[] = [
  { key: "currency", label: "Валюта (RUB)", numeric: false },
  { key: "baseCityPrice", label: "База по городу", numeric: true },
  { key: "cityKmIncluded", label: "Км включено", numeric: true },
  { key: "cityPerKm", label: "Цена/км в городе", numeric: true },
  { key: "mkadExitFee", label: "Выезд за МКАД", numeric: true },
  { key: "moPerKm", label: "Цена/км за МКАД", numeric: true },
  { key: "minOrderPrice", label: "Минимальный заказ", numeric: true },
  { key: "loaderHourRate", label: "Грузчик/час", numeric: true },
  { key: "loadingMinHours", label: "Мин. часов грузчиков", numeric: true },
  { key: "extraStopFee", label: "Доп. остановка", numeric: true },
];

const DRIVER_FIELDS: { key: DriverField; label: string; numeric: boolean; maxLength?: number }[] = [
  { key: "fullName", label: "ФИО", numeric: false, maxLength: 100 },
  { key: "phone", label: "Телефон", numeric: false, maxLength: 25 },
  { key: "carModel", label: "Модель авто", numeric: false, maxLength: 100 },
  { key: "carType", label: "Тип кузова", numeric: false, maxLength: 100 },
  { key: "maxPayloadKg", label: "Грузоподъёмность (кг)", numeric: true },
  { key: "lengthCm", label: "Длина кузова (см)", numeric: true },
  { key: "widthCm", label: "Ширина кузова (см)", numeric: true },
  { key: "heightCm", label: "Высота кузова (см)", numeric: true },
  { key: "volumeM3", label: "Объём кузова (м³)", numeric: false, maxLength: 20 },
  { key: "serviceArea", label: "Зона работы", numeric: false, maxLength: 120 },
  { key: "notes", label: "О себе / комментарий", numeric: false, maxLength: 500 },
];

async function getSettings() {
  const [row] = await db.select().from(pricingSettings).orderBy(desc(pricingSettings.id)).limit(1);
  if (row) return row;
  const inserted = await db.insert(pricingSettings).values({}).returning();
  return inserted[0]!;
}

async function getSession(chatId: string): Promise<SessionState> {
  const [row] = await db.select().from(tgSessions).where(eq(tgSessions.chatId, chatId)).limit(1);
  if (row?.state) return row.state as SessionState;
  return { step: "idle", data: {} };
}

async function saveSession(chatId: string, state: SessionState) {
  const now = new Date();
  const existing = await db.select().from(tgSessions).where(eq(tgSessions.chatId, chatId)).limit(1);
  if (existing.length) {
    await db.update(tgSessions).set({ state, updatedAt: now }).where(eq(tgSessions.chatId, chatId));
  } else {
    await db.insert(tgSessions).values({ chatId, state, updatedAt: now });
  }
}

function normalizeCurrency(input?: string) {
  const candidate = (input || "RUB").trim().toUpperCase();
  return /^[A-Z]{3}$/.test(candidate) ? candidate : "RUB";
}

function formatMoney(v: number, currency: string) {
  const safeCurrency = normalizeCurrency(currency);
  try {
    return new Intl.NumberFormat("ru-RU", { style: "currency", currency: safeCurrency }).format(v);
  } catch {
    return `${Math.round(v)} ₽`;
  }
}

function getOwnerIds() {
  const raw = process.env.TELEGRAM_OWNER_IDS || "";
  return new Set(
    raw
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean),
  );
}

function isOwner(userId?: number) {
  if (!userId) return false;
  return getOwnerIds().has(String(userId));
}

async function callTelegram(method: string, payload: Record<string, unknown>) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.error("TELEGRAM_BOT_TOKEN is not set");
    return null;
  }

  const url = `https://api.telegram.org/bot${token}/${method}`;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });

    const text = await res.text();
    if (!res.ok) {
      console.error(`Telegram method ${method} failed`, res.status, text);
      return null;
    }

    return text ? JSON.parse(text) : null;
  } catch (error) {
    console.error(`Telegram method ${method} network error`, error);
    return null;
  }
}

async function sendMessage(chatId: number | string, text: string, replyMarkup?: Record<string, unknown>) {
  await callTelegram("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
  });
}

async function answerCallbackQuery(callbackQueryId: string) {
  await callTelegram("answerCallbackQuery", { callback_query_id: callbackQueryId });
}

function mainMenuKeyboard(owner: boolean) {
  const rows: Array<Array<{ text: string; callback_data: string }>> = [
    [{ text: "🚚 Рассчитать стоимость", callback_data: "quote:start" }],
    [{ text: "🚗 Моя визитка водителя", callback_data: "drv:menu" }],
  ];
  if (owner) {
    rows.push([{ text: "⚙️ Настройки тарифов (владелец)", callback_data: "admin:menu" }]);
  }
  return { inline_keyboard: rows };
}

function tripTypeKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: "Внутри МКАД", callback_data: "quote:trip:city" },
        { text: "За МКАД", callback_data: "quote:trip:mo" },
      ],
      [{ text: "⬅️ В меню", callback_data: "menu" }],
    ],
  };
}

function adminKeyboard() {
  const rows = ADMIN_FIELDS.map((f) => [{ text: f.label, callback_data: `admin:set:${f.key}` }]);
  rows.push([{ text: "⬅️ В меню", callback_data: "menu" }]);
  return { inline_keyboard: rows };
}

function driverKeyboard(driver: Exclude<DriverRow, null>) {
  return {
    inline_keyboard: [
      [{ text: "👁 Показать мою визитку", callback_data: "drv:view" }],
      [
        { text: "ФИО", callback_data: "drv:edit:fullName" },
        { text: "Телефон", callback_data: "drv:edit:phone" },
      ],
      [
        { text: "Модель авто", callback_data: "drv:edit:carModel" },
        { text: "Тип кузова", callback_data: "drv:edit:carType" },
      ],
      [
        { text: "Г/п кг", callback_data: "drv:edit:maxPayloadKg" },
        { text: "Объём м³", callback_data: "drv:edit:volumeM3" },
      ],
      [
        { text: "Длина см", callback_data: "drv:edit:lengthCm" },
        { text: "Ширина см", callback_data: "drv:edit:widthCm" },
        { text: "Высота см", callback_data: "drv:edit:heightCm" },
      ],
      [
        { text: "Зона работы", callback_data: "drv:edit:serviceArea" },
        { text: "Комментарий", callback_data: "drv:edit:notes" },
      ],
      [
        {
          text: driver.isActive ? "🟢 Активен (нажмите выключить)" : "⚪️ Неактивен (нажмите включить)",
          callback_data: "drv:toggle",
        },
      ],
      [{ text: "⬅️ В меню", callback_data: "menu" }],
    ],
  };
}

function greeting(owner: boolean) {
  return owner
    ? "Здравствуйте! Я бот расчёта перевозки до 1 т по Москве и МО.\n\nВам доступно меню владельца и личная визитка водителя."
    : "Здравствуйте! Я бот расчёта перевозки до 1 т по Москве и МО.\n\nНажмите кнопку ниже, чтобы начать расчёт или заполнить визитку водителя.";
}

function computeTotal(inputs: SessionState["data"], s: PricingRow) {
  const breakdown: string[] = [];
  let total = 0;
  const currency = normalizeCurrency(s.currency);

  if (inputs.tripType === "city") {
    const extraKm = Math.max(0, (inputs.cityKm ?? 0) - s.cityKmIncluded);
    const extra = extraKm * s.cityPerKm;
    total = s.baseCityPrice + extra;
    breakdown.push(`База по городу: ${formatMoney(s.baseCityPrice, currency)}`);
    if (extraKm > 0) breakdown.push(`Доп. км по городу (${extraKm}): ${formatMoney(extra, currency)}`);
  } else if (inputs.tripType === "mo") {
    const outsideKm = Math.max(0, inputs.moOutsideKm ?? 0);
    const outside = outsideKm * s.moPerKm;
    total = s.baseCityPrice + s.mkadExitFee + outside;
    breakdown.push(`База по городу: ${formatMoney(s.baseCityPrice, currency)}`);
    breakdown.push(`Выезд за МКАД: ${formatMoney(s.mkadExitFee, currency)}`);
    if (outsideKm > 0) breakdown.push(`Км за МКАД (${outsideKm}): ${formatMoney(outside, currency)}`);
  }

  const extraStops = Math.max(0, inputs.extraStops ?? 0);
  if (extraStops > 0) {
    const fee = extraStops * s.extraStopFee;
    total += fee;
    breakdown.push(`Доп. остановки (${extraStops}): ${formatMoney(fee, currency)}`);
  }

  const loaders = Math.max(0, inputs.loadersCount ?? 0);
  const hours = Math.max(0, inputs.loadingHours ?? 0);
  if (loaders > 0 && hours > 0) {
    const billHours = Math.max(hours, s.loadingMinHours);
    const loading = loaders * billHours * s.loaderHourRate;
    total += loading;
    breakdown.push(`Грузчики (${loaders} × ${billHours} ч): ${formatMoney(loading, currency)}`);
  }

  if (total < s.minOrderPrice) {
    total = s.minOrderPrice;
    breakdown.push(`Минимальный заказ: ${formatMoney(s.minOrderPrice, currency)}`);
  }

  return { total, breakdown, currency };
}

async function saveNewSettingsVersion(base: PricingRow, patch: Partial<Record<AdminField, number | string>>) {
  await db.insert(pricingSettings).values({
    currency: normalizeCurrency(String(patch.currency ?? base.currency)),
    baseCityPrice: Number(patch.baseCityPrice ?? base.baseCityPrice),
    cityKmIncluded: Number(patch.cityKmIncluded ?? base.cityKmIncluded),
    cityPerKm: Number(patch.cityPerKm ?? base.cityPerKm),
    mkadExitFee: Number(patch.mkadExitFee ?? base.mkadExitFee),
    moPerKm: Number(patch.moPerKm ?? base.moPerKm),
    minOrderPrice: Number(patch.minOrderPrice ?? base.minOrderPrice),
    loaderHourRate: Number(patch.loaderHourRate ?? base.loaderHourRate),
    loadingMinHours: Number(patch.loadingMinHours ?? base.loadingMinHours),
    extraStopFee: Number(patch.extraStopFee ?? base.extraStopFee),
    updatedAt: new Date(),
  });
}

function currentDriverName(from: { first_name?: string; last_name?: string; username?: string }) {
  const full = [from.first_name || "", from.last_name || ""].join(" ").trim();
  if (full) return full;
  if (from.username) return `@${from.username}`;
  return "";
}

async function getDriverProfile(userId: string) {
  const [row] = await db.select().from(tgDrivers).where(eq(tgDrivers.userId, userId)).limit(1);
  return row ?? null;
}

async function ensureDriverProfile(
  userId: string,
  chatId: string,
  from: { first_name?: string; last_name?: string; username?: string },
) {
  const existing = await getDriverProfile(userId);
  if (existing) return existing;

  const inserted = await db
    .insert(tgDrivers)
    .values({
      userId,
      chatId,
      fullName: currentDriverName(from),
      serviceArea: "Москва и МО",
      maxPayloadKg: 1000,
      isActive: true,
      updatedAt: new Date(),
    })
    .returning();

  return inserted[0]!;
}

async function updateDriverProfile(userId: string, chatId: string, patch: Partial<typeof tgDrivers.$inferInsert>) {
  const now = new Date();
  const existing = await getDriverProfile(userId);
  if (existing) {
    await db
      .update(tgDrivers)
      .set({ ...patch, chatId, updatedAt: now })
      .where(eq(tgDrivers.userId, userId));
    return;
  }

  await db.insert(tgDrivers).values({
    userId,
    chatId,
    fullName: "",
    phone: "",
    carModel: "",
    carType: "",
    maxPayloadKg: 1000,
    lengthCm: 0,
    widthCm: 0,
    heightCm: 0,
    volumeM3: "",
    serviceArea: "Москва и МО",
    notes: "",
    isActive: true,
    updatedAt: now,
    ...patch,
  });
}

function driverCardText(driver: Exclude<DriverRow, null>) {
  return [
    "<b>Визитка водителя</b>",
    `ФИО: ${driver.fullName || "—"}`,
    `Телефон: ${driver.phone || "—"}`,
    `Авто: ${driver.carModel || "—"}`,
    `Тип кузова: ${driver.carType || "—"}`,
    `Грузоподъёмность: ${driver.maxPayloadKg || 0} кг`,
    `Габариты кузова: ${driver.lengthCm || 0} × ${driver.widthCm || 0} × ${driver.heightCm || 0} см`,
    `Объём: ${driver.volumeM3 || "—"} м³`,
    `Зона работы: ${driver.serviceArea || "—"}`,
    `Статус: ${driver.isActive ? "🟢 Активен" : "⚪️ Неактивен"}`,
    `Комментарий: ${driver.notes || "—"}`,
  ].join("\n");
}

function promptForDriverField(field: DriverField, driver: Exclude<DriverRow, null>) {
  const meta = DRIVER_FIELDS.find((f) => f.key === field);
  const label = meta?.label || field;
  const current = String(driver[field] ?? "");
  if (meta?.numeric) {
    return `Введите новое значение для «${label}».\nТекущее: <b>${current || "0"}</b>`;
  }
  return `Введите новое значение для «${label}».\nТекущее: <b>${current || "—"}</b>`;
}

async function handleCallback(update: any) {
  const query = update.callback_query;
  if (!query) return;

  await answerCallbackQuery(String(query.id));

  const data = String(query.data || "");
  const chatId = String(query.message?.chat?.id || "");
  const userId = String(query.from?.id || "");
  const owner = isOwner(Number(query.from?.id || 0));

  if (!chatId || !userId) return;

  if (data === "menu") {
    await saveSession(chatId, { step: "idle", data: {} });
    await sendMessage(chatId, greeting(owner), mainMenuKeyboard(owner));
    return;
  }

  if (data === "quote:start") {
    await saveSession(chatId, { step: "quote_trip_type", data: {} });
    await sendMessage(chatId, "Выберите тип поездки:", tripTypeKeyboard());
    return;
  }

  if (data === "quote:trip:city") {
    await saveSession(chatId, { step: "quote_city_km", data: { tripType: "city" } });
    await sendMessage(chatId, "Введите общий пробег по городу (км), например: 25");
    return;
  }

  if (data === "quote:trip:mo") {
    await saveSession(chatId, { step: "quote_mo_outside_km", data: { tripType: "mo" } });
    await sendMessage(chatId, "Введите пробег за МКАД (км), например: 30");
    return;
  }

  if (data === "admin:menu") {
    if (!owner) {
      await sendMessage(chatId, "Недостаточно прав.");
      return;
    }
    await saveSession(chatId, { step: "idle", data: {} });
    await sendMessage(chatId, "Выберите параметр для изменения:", adminKeyboard());
    return;
  }

  if (data.startsWith("admin:set:")) {
    if (!owner) {
      await sendMessage(chatId, "Недостаточно прав.");
      return;
    }

    const field = data.replace("admin:set:", "") as AdminField;
    if (!ADMIN_FIELDS.some((f) => f.key === field)) {
      await sendMessage(chatId, "Неизвестный параметр.");
      return;
    }

    const state = await getSession(chatId);
    state.step = "admin_wait_value";
    state.adminField = field;
    await saveSession(chatId, state);

    const s = await getSettings();
    const meta = ADMIN_FIELDS.find((x) => x.key === field)!;
    await sendMessage(chatId, `Введите значение для «${meta.label}».\nТекущее: <b>${String(s[field])}</b>`);
    return;
  }

  if (data === "drv:menu") {
    const driver = await ensureDriverProfile(userId, chatId, query.from || {});
    await saveSession(chatId, { step: "idle", data: {} });
    await sendMessage(chatId, "Меню визитки водителя. Выберите действие:", driverKeyboard(driver));
    return;
  }

  if (data === "drv:view") {
    const driver = await ensureDriverProfile(userId, chatId, query.from || {});
    await sendMessage(chatId, driverCardText(driver), driverKeyboard(driver));
    return;
  }

  if (data === "drv:toggle") {
    const driver = await ensureDriverProfile(userId, chatId, query.from || {});
    await updateDriverProfile(userId, chatId, { isActive: !driver.isActive });
    const updated = await getDriverProfile(userId);
    if (updated) {
      await sendMessage(chatId, `Статус обновлён: ${updated.isActive ? "🟢 Активен" : "⚪️ Неактивен"}`, driverKeyboard(updated));
    }
    return;
  }

  if (data.startsWith("drv:edit:")) {
    const field = data.replace("drv:edit:", "") as DriverField;
    if (!DRIVER_FIELDS.some((f) => f.key === field)) {
      await sendMessage(chatId, "Неизвестное поле визитки.");
      return;
    }

    const driver = await ensureDriverProfile(userId, chatId, query.from || {});
    const state = await getSession(chatId);
    state.step = "driver_wait_value";
    state.driverField = field;
    await saveSession(chatId, state);

    await sendMessage(chatId, promptForDriverField(field, driver));
    return;
  }
}

async function handleDriverFieldInput(
  chatId: string,
  userId: string,
  text: string,
  field: DriverField,
  owner: boolean,
) {
  const meta = DRIVER_FIELDS.find((f) => f.key === field)!;

  if (meta.numeric) {
    const n = Number(text.replace(",", "."));
    if (!Number.isFinite(n) || n < 0) {
      await sendMessage(chatId, "Введите корректное неотрицательное число.");
      return;
    }

    const safe = Math.round(n);
    await updateDriverProfile(userId, chatId, { [field]: safe });
  } else {
    const value = text.trim();
    if (!value) {
      await sendMessage(chatId, "Значение не должно быть пустым.");
      return;
    }

    if (meta.maxLength && value.length > meta.maxLength) {
      await sendMessage(chatId, `Слишком длинное значение. Максимум: ${meta.maxLength} символов.`);
      return;
    }

    if (field === "phone") {
      const cleaned = value.replace(/\s+/g, "");
      if (!/^\+?[0-9()\-]{6,25}$/.test(cleaned)) {
        await sendMessage(chatId, "Введите телефон в корректном формате, например +79991234567");
        return;
      }
    }

    await updateDriverProfile(userId, chatId, { [field]: value });
  }

  const updated = await getDriverProfile(userId);
  if (!updated) return;

  await saveSession(chatId, { step: "idle", data: {} });
  await sendMessage(chatId, `✅ Поле «${meta.label}» обновлено.`, driverKeyboard(updated));
  await sendMessage(chatId, driverCardText(updated), mainMenuKeyboard(owner));
}

async function handleText(update: any) {
  const message = update.message ?? update.edited_message ?? null;
  if (!message) return;

  const chatId = String(message.chat.id);
  const text = String(message.text ?? "").trim();
  const userId = String(message.from?.id || "");
  const owner = isOwner(Number(message.from?.id || 0));

  if (!userId) return;

  if (text.startsWith("/start") || text === "/menu") {
    await saveSession(chatId, { step: "idle", data: {} });
    await sendMessage(chatId, greeting(owner), mainMenuKeyboard(owner));
    return;
  }

  if (text === "/reset") {
    await saveSession(chatId, { step: "quote_trip_type", data: {} });
    await sendMessage(chatId, "Сессия расчёта сброшена. Выберите тип поездки:", tripTypeKeyboard());
    return;
  }

  if (text === "/settings") {
    if (!owner) {
      await sendMessage(chatId, "Недостаточно прав.");
      return;
    }
    await saveSession(chatId, { step: "idle", data: {} });
    await sendMessage(chatId, "Панель настройки тарифов:", adminKeyboard());
    return;
  }

  if (text === "/mycard") {
    const driver = await ensureDriverProfile(userId, chatId, message.from || {});
    await sendMessage(chatId, driverCardText(driver), driverKeyboard(driver));
    return;
  }

  const s = await getSettings();
  const state = await getSession(chatId);

  if (state.step === "admin_wait_value") {
    if (!owner) {
      await sendMessage(chatId, "Недостаточно прав.");
      return;
    }

    const field = state.adminField;
    if (!field) {
      await saveSession(chatId, { step: "idle", data: {} });
      await sendMessage(chatId, "Состояние сброшено. Откройте настройки заново.", adminKeyboard());
      return;
    }

    const meta = ADMIN_FIELDS.find((x) => x.key === field)!;

    if (!meta.numeric) {
      const currency = normalizeCurrency(text);
      await saveNewSettingsVersion(s, { [field]: currency });
      await saveSession(chatId, { step: "idle", data: {} });
      await sendMessage(chatId, `✅ Обновлено: ${meta.label} = ${currency}`, adminKeyboard());
      return;
    }

    const n = Number(text.replace(",", "."));
    if (!Number.isFinite(n) || n < 0) {
      await sendMessage(chatId, "Введите неотрицательное число.");
      return;
    }

    const safeInt = Math.round(n);
    await saveNewSettingsVersion(s, { [field]: safeInt });
    await saveSession(chatId, { step: "idle", data: {} });
    await sendMessage(chatId, `✅ Обновлено: ${meta.label} = ${safeInt}`, adminKeyboard());
    return;
  }

  if (state.step === "driver_wait_value") {
    const field = state.driverField;
    if (!field) {
      await saveSession(chatId, { step: "idle", data: {} });
      await sendMessage(chatId, "Состояние визитки сброшено. Откройте меню визитки заново.", mainMenuKeyboard(owner));
      return;
    }

    await handleDriverFieldInput(chatId, userId, text, field, owner);
    return;
  }

  switch (state.step) {
    case "quote_city_km": {
      const n = Number(text.replace(",", "."));
      if (!Number.isFinite(n) || n < 0) {
        await sendMessage(chatId, "Введите корректное число км по городу (например, 25)");
        return;
      }
      state.data.cityKm = Math.round(n);
      state.step = "quote_extra_stops";
      await saveSession(chatId, state);
      await sendMessage(chatId, "Введите количество доп. остановок (0, 1, 2 ...):");
      return;
    }

    case "quote_mo_outside_km": {
      const n = Number(text.replace(",", "."));
      if (!Number.isFinite(n) || n < 0) {
        await sendMessage(chatId, "Введите корректное число км за МКАД (например, 30)");
        return;
      }
      state.data.moOutsideKm = Math.round(n);
      state.step = "quote_extra_stops";
      await saveSession(chatId, state);
      await sendMessage(chatId, "Введите количество доп. остановок (0, 1, 2 ...):");
      return;
    }

    case "quote_extra_stops": {
      const n = Number(text);
      if (!Number.isFinite(n) || n < 0) {
        await sendMessage(chatId, "Введите корректное количество остановок (0, 1, 2 ...)");
        return;
      }
      state.data.extraStops = Math.round(n);
      state.step = "quote_loaders_count";
      await saveSession(chatId, state);
      await sendMessage(chatId, "Введите количество грузчиков (0, 1, 2 ...):");
      return;
    }

    case "quote_loaders_count": {
      const n = Number(text);
      if (!Number.isFinite(n) || n < 0 || n > 10) {
        await sendMessage(chatId, "Введите количество грузчиков от 0 до 10");
        return;
      }
      state.data.loadersCount = Math.round(n);
      if (state.data.loadersCount === 0) {
        const { total, breakdown, currency } = computeTotal(state.data, s);
        await db.insert(tgQuotes).values({ chatId, payload: state.data as unknown as object, total });
        await sendMessage(
          chatId,
          `${breakdown.join("\n")}\n\nИтого: <b>${formatMoney(total, currency)}</b>\n\nНовый расчёт: нажмите кнопку ниже.`,
          mainMenuKeyboard(owner),
        );
        await saveSession(chatId, { step: "idle", data: {} });
        return;
      }
      state.step = "quote_loading_hours";
      await saveSession(chatId, state);
      await sendMessage(chatId, `Введите часы работы грузчиков (мин. ${s.loadingMinHours}):`);
      return;
    }

    case "quote_loading_hours": {
      const n = Number(text.replace(",", "."));
      if (!Number.isFinite(n) || n <= 0 || n > 48) {
        await sendMessage(chatId, "Введите корректное число часов (например, 2)");
        return;
      }
      state.data.loadingHours = Math.ceil(n);
      const { total, breakdown, currency } = computeTotal(state.data, s);
      await db.insert(tgQuotes).values({ chatId, payload: state.data as unknown as object, total });
      await sendMessage(
        chatId,
        `${breakdown.join("\n")}\n\nИтого: <b>${formatMoney(total, currency)}</b>\n\nНовый расчёт: нажмите кнопку ниже.`,
        mainMenuKeyboard(owner),
      );
      await saveSession(chatId, { step: "idle", data: {} });
      return;
    }

    default:
      await sendMessage(chatId, "Используйте кнопки меню:", mainMenuKeyboard(owner));
      return;
  }
}

export async function POST(req: Request) {
  try {
    const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
    if (secret) {
      const header = req.headers.get("x-telegram-bot-api-secret-token");
      if (header !== secret) {
        return new Response("forbidden", { status: 403 });
      }
    }

    const update = await req.json().catch(() => null);
    if (!update) return Response.json({ ok: true });

    if (update.callback_query) {
      await handleCallback(update);
      return Response.json({ ok: true });
    }

    await handleText(update);
    return Response.json({ ok: true });
  } catch (error) {
    console.error("Telegram webhook fatal error", error);
    return Response.json({ ok: true });
  }
}

export async function GET() {
  return Response.json({ ok: true });
}
