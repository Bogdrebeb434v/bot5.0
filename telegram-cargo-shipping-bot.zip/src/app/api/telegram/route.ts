import { handleUpdate } from "@/bot/handler";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
    if (secret) {
      const header = req.headers.get("x-telegram-bot-api-secret-token");
      if (header !== secret) {
        return new Response("forbidden", { status: 403 });
      }
    }

    const update = await req.json().catch(() => null);
    if (!update) return Response.json({ ok: true });

    await handleUpdate(update);
    return Response.json({ ok: true });
  } catch (error) {
    console.error("Telegram webhook fatal error", error);
    return Response.json({ ok: true });
  }
}

export async function GET() {
  return Response.json({ ok: true });
}
