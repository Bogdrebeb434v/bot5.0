# Telegram-бот расчёта перевозки (только чат-бот с кнопками)

Готовый проект: **Next.js + PostgreSQL + Drizzle**, где сайт не нужен для работы пользователей.
Сервер используется только как backend для Telegram webhook.

## Что умеет бот

- Работает как чат-бот в Telegram с inline-кнопками.
- Считает стоимость перевозки до 1 тонны:
  - внутри МКАД;
  - за МКАД.
- Учитывает:
  - базовую стоимость,
  - километраж,
  - выезд за МКАД,
  - доп. остановки,
  - грузчиков (кол-во и часы),
  - минимальный заказ.
- Поддерживает персональные профили водителей:
  - у каждого водителя своя визитка,
  - свои характеристики авто,
  - свой статус активности.

## Управление без сайта

### Тарифы (владелец)

Владелец бота меняет тарифы **прямо в Telegram** через кнопку:

- `⚙️ Настройки тарифов (владелец)`

Чтобы дать доступ владельцу, укажите его Telegram user id в ENV:

- `TELEGRAM_OWNER_IDS=123456789,987654321`

### Визитка водителя (каждый пользователь сам)

Каждый новый водитель открывает кнопку:

- `🚗 Моя визитка водителя`

и настраивает свои данные:
- ФИО,
- телефон,
- модель авто,
- тип кузова,
- грузоподъёмность,
- габариты,
- объём,
- зона работы,
- комментарий,
- активность.

Команды:

- `/start` — главное меню
- `/menu` — открыть меню
- `/reset` — сбросить расчёт
- `/settings` — открыть тарифы (только владелец)
- `/mycard` — показать/редактировать свою визитку водителя

## Переменные окружения

Создайте `.env` по примеру `.env.example`.

Обязательно:

- `DATABASE_URL=postgresql://...`
- `TELEGRAM_BOT_TOKEN=...`
- `PUBLIC_BASE_URL=https://your-domain.com`
- `TELEGRAM_OWNER_IDS=123456789`

Рекомендуется:

- `TELEGRAM_WEBHOOK_SECRET=your_secret`

## Запуск

```bash
npm install
npx drizzle-kit push
npm run build
npm run start
```

## Установка webhook

Webhook endpoint:

- `POST /api/telegram`

Установить webhook можно через Telegram API вручную:

```bash
curl -X POST "https://api.telegram.org/bot<TELEGRAM_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://your-domain.com/api/telegram",
    "secret_token": "your_secret"
  }'
```

Проверить:

```bash
curl "https://api.telegram.org/bot<TELEGRAM_BOT_TOKEN>/getWebhookInfo"
```

## База данных

Таблицы:

- `pricing_settings` — настройки тарифа
- `tg_sessions` — состояние диалога
- `tg_quotes` — история расчётов

Применение схемы:

```bash
npx drizzle-kit push
```

## Деплой

Можно деплоить на любой сервер/платформу с Node.js и PostgreSQL.
Главное условие: публичный HTTPS домен для Telegram webhook.
